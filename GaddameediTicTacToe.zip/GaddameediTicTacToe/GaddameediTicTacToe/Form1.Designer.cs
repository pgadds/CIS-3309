﻿namespace GaddameediTicTacToe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblFirstPlayer = new System.Windows.Forms.Label();
            this.lblSecondPlayer = new System.Windows.Forms.Label();
            this.lblReadyPlay = new System.Windows.Forms.Label();
            this.lblTurn = new System.Windows.Forms.Label();
            this.btnOKPlayerOne = new System.Windows.Forms.Button();
            this.btnOKPlayerTwo = new System.Windows.Forms.Button();
            this.btnLetsPlay = new System.Windows.Forms.Button();
            this.btnStopGame = new System.Windows.Forms.Button();
            this.txtFirstPlayer = new System.Windows.Forms.TextBox();
            this.txtSecondPlayer = new System.Windows.Forms.TextBox();
            this.txtCurrentPlayer = new System.Windows.Forms.TextBox();
            this.pnlGame = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(471, 41);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(227, 25);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome to Tic Tac Toe";
            // 
            // lblFirstPlayer
            // 
            this.lblFirstPlayer.AutoSize = true;
            this.lblFirstPlayer.Location = new System.Drawing.Point(261, 105);
            this.lblFirstPlayer.Name = "lblFirstPlayer";
            this.lblFirstPlayer.Size = new System.Drawing.Size(166, 25);
            this.lblFirstPlayer.TabIndex = 1;
            this.lblFirstPlayer.Text = "First Player Name";
            // 
            // lblSecondPlayer
            // 
            this.lblSecondPlayer.AutoSize = true;
            this.lblSecondPlayer.Location = new System.Drawing.Point(261, 169);
            this.lblSecondPlayer.Name = "lblSecondPlayer";
            this.lblSecondPlayer.Size = new System.Drawing.Size(197, 25);
            this.lblSecondPlayer.TabIndex = 2;
            this.lblSecondPlayer.Text = "Second Player Name";
            this.lblSecondPlayer.Visible = false;
            // 
            // lblReadyPlay
            // 
            this.lblReadyPlay.AutoSize = true;
            this.lblReadyPlay.Location = new System.Drawing.Point(75, 284);
            this.lblReadyPlay.Name = "lblReadyPlay";
            this.lblReadyPlay.Size = new System.Drawing.Size(217, 25);
            this.lblReadyPlay.TabIndex = 3;
            this.lblReadyPlay.Text = "When Ready Click Play";
            this.lblReadyPlay.Visible = false;
            // 
            // lblTurn
            // 
            this.lblTurn.AutoSize = true;
            this.lblTurn.Location = new System.Drawing.Point(37, 468);
            this.lblTurn.Name = "lblTurn";
            this.lblTurn.Size = new System.Drawing.Size(99, 25);
            this.lblTurn.TabIndex = 4;
            this.lblTurn.Text = "Your Turn";
            // 
            // btnOKPlayerOne
            // 
            this.btnOKPlayerOne.Location = new System.Drawing.Point(701, 97);
            this.btnOKPlayerOne.Name = "btnOKPlayerOne";
            this.btnOKPlayerOne.Size = new System.Drawing.Size(83, 40);
            this.btnOKPlayerOne.TabIndex = 5;
            this.btnOKPlayerOne.Text = "OK";
            this.btnOKPlayerOne.UseVisualStyleBackColor = true;
            this.btnOKPlayerOne.Click += new System.EventHandler(this.btnOKPlayerOne_Click);
            // 
            // btnOKPlayerTwo
            // 
            this.btnOKPlayerTwo.Location = new System.Drawing.Point(701, 159);
            this.btnOKPlayerTwo.Name = "btnOKPlayerTwo";
            this.btnOKPlayerTwo.Size = new System.Drawing.Size(83, 45);
            this.btnOKPlayerTwo.TabIndex = 6;
            this.btnOKPlayerTwo.Text = "OK";
            this.btnOKPlayerTwo.UseVisualStyleBackColor = true;
            this.btnOKPlayerTwo.Visible = false;
            this.btnOKPlayerTwo.Click += new System.EventHandler(this.btnOKPlayerTwo_Click);
            // 
            // btnLetsPlay
            // 
            this.btnLetsPlay.Location = new System.Drawing.Point(90, 340);
            this.btnLetsPlay.Name = "btnLetsPlay";
            this.btnLetsPlay.Size = new System.Drawing.Size(109, 63);
            this.btnLetsPlay.TabIndex = 7;
            this.btnLetsPlay.Text = "Let\'s Play";
            this.btnLetsPlay.UseVisualStyleBackColor = true;
            this.btnLetsPlay.Visible = false;
            this.btnLetsPlay.Click += new System.EventHandler(this.btnLetsPlay_Click);
            // 
            // btnStopGame
            // 
            this.btnStopGame.Location = new System.Drawing.Point(877, 118);
            this.btnStopGame.Name = "btnStopGame";
            this.btnStopGame.Size = new System.Drawing.Size(119, 67);
            this.btnStopGame.TabIndex = 8;
            this.btnStopGame.Text = "Stop";
            this.btnStopGame.UseVisualStyleBackColor = true;
            this.btnStopGame.Click += new System.EventHandler(this.btnStopGame_Click);
            // 
            // txtFirstPlayer
            // 
            this.txtFirstPlayer.Location = new System.Drawing.Point(518, 102);
            this.txtFirstPlayer.Name = "txtFirstPlayer";
            this.txtFirstPlayer.Size = new System.Drawing.Size(146, 29);
            this.txtFirstPlayer.TabIndex = 9;
            // 
            // txtSecondPlayer
            // 
            this.txtSecondPlayer.Location = new System.Drawing.Point(518, 166);
            this.txtSecondPlayer.Name = "txtSecondPlayer";
            this.txtSecondPlayer.Size = new System.Drawing.Size(146, 29);
            this.txtSecondPlayer.TabIndex = 10;
            this.txtSecondPlayer.Visible = false;
            // 
            // txtCurrentPlayer
            // 
            this.txtCurrentPlayer.Location = new System.Drawing.Point(17, 551);
            this.txtCurrentPlayer.Name = "txtCurrentPlayer";
            this.txtCurrentPlayer.Size = new System.Drawing.Size(119, 29);
            this.txtCurrentPlayer.TabIndex = 11;
            this.txtCurrentPlayer.Visible = false;
            // 
            // pnlGame
            // 
            this.pnlGame.Location = new System.Drawing.Point(376, 263);
            this.pnlGame.Name = "pnlGame";
            this.pnlGame.Size = new System.Drawing.Size(788, 729);
            this.pnlGame.TabIndex = 12;
            this.pnlGame.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1215, 1062);
            this.Controls.Add(this.btnStopGame);
            this.Controls.Add(this.pnlGame);
            this.Controls.Add(this.txtCurrentPlayer);
            this.Controls.Add(this.txtSecondPlayer);
            this.Controls.Add(this.txtFirstPlayer);
            this.Controls.Add(this.btnLetsPlay);
            this.Controls.Add(this.btnOKPlayerTwo);
            this.Controls.Add(this.btnOKPlayerOne);
            this.Controls.Add(this.lblTurn);
            this.Controls.Add(this.lblReadyPlay);
            this.Controls.Add(this.lblSecondPlayer);
            this.Controls.Add(this.lblFirstPlayer);
            this.Controls.Add(this.lblWelcome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblFirstPlayer;
        private System.Windows.Forms.Label lblSecondPlayer;
        private System.Windows.Forms.Label lblReadyPlay;
        private System.Windows.Forms.Label lblTurn;
        private System.Windows.Forms.Button btnOKPlayerOne;
        private System.Windows.Forms.Button btnOKPlayerTwo;
        private System.Windows.Forms.Button btnLetsPlay;
        private System.Windows.Forms.Button btnStopGame;
        private System.Windows.Forms.TextBox txtFirstPlayer;
        private System.Windows.Forms.TextBox txtSecondPlayer;
        private System.Windows.Forms.TextBox txtCurrentPlayer;
        private System.Windows.Forms.Panel pnlGame;
    }
}

