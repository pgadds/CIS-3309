﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaddameediTicTacToe
{
    class playerModel
    {
        private string hiddenName;
        private int hiddenWins;
        private char hiddenIcon;

        public playerModel(string name, char icon)
        {
            hiddenName = name;
            hiddenIcon = icon;
            hiddenWins = 0;
        } // end New


        // Read only properties
        public char Icon
        {
            get { return hiddenIcon; }
        } // end property Icon

        public string Name
        {
            get { return hiddenName; }
        } // end property Name


        public int Wins
        {
            get { return hiddenWins; }
        } // end property Wins


        // Increment number of wins for this player
        public void won()
        {
            hiddenWins = hiddenWins + 1;
        } // end isWin
    }
}
