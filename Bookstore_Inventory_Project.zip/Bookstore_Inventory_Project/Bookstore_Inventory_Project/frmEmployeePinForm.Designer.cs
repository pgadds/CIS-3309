﻿namespace Bookstore_Inventory_Project
{
    partial class frmEmployeePinForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPinEntry = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.txtPin = new System.Windows.Forms.TextBox();
            this.lblEnterPin = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPinEntry
            // 
            this.lblPinEntry.AutoSize = true;
            this.lblPinEntry.Location = new System.Drawing.Point(427, 82);
            this.lblPinEntry.Name = "lblPinEntry";
            this.lblPinEntry.Size = new System.Drawing.Size(140, 25);
            this.lblPinEntry.TabIndex = 0;
            this.lblPinEntry.Text = "Pin Entry Form";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(779, 339);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(105, 41);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // txtPin
            // 
            this.txtPin.Location = new System.Drawing.Point(432, 339);
            this.txtPin.Name = "txtPin";
            this.txtPin.Size = new System.Drawing.Size(191, 29);
            this.txtPin.TabIndex = 2;
            // 
            // lblEnterPin
            // 
            this.lblEnterPin.AutoSize = true;
            this.lblEnterPin.Location = new System.Drawing.Point(93, 343);
            this.lblEnterPin.Name = "lblEnterPin";
            this.lblEnterPin.Size = new System.Drawing.Size(234, 25);
            this.lblEnterPin.TabIndex = 3;
            this.lblEnterPin.Text = "Enter Pin and Press OK...";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(779, 547);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(105, 45);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click_1);
            // 
            // frmEmployeePinForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 685);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblEnterPin);
            this.Controls.Add(this.txtPin);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.lblPinEntry);
            this.Name = "frmEmployeePinForm";
            this.Text = "frmEmployeePinForm";
            //this.Load += new System.EventHandler(this.frmEmployeePinForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPinEntry;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.TextBox txtPin;
        private System.Windows.Forms.Label lblEnterPin;
        private System.Windows.Forms.Button btnExit;
    }
}