﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PranavG_Lab4._2
{
    public partial class Form1 : Form
    {
        private string userName;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
          


            userName = txtName.Text; 
            if (userName == "")
            {
                MessageBox.Show("User Name" + "is a required field. Reenter Name", "Entry Error!");
                txtName.Focus();
            }
            else
            {
                txtSubtotal.Enabled = true;
                lblSubtotal.Enabled = true;
                btnCalculate.Enabled = true; 
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                decimal Subtotal = Convert.ToDecimal(txtSubtotal.Text);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" + ex.GetType().ToString() + "\n" +
                    ex.StackTrace, "Exception");

            }
            

            decimal subtotal = Convert.ToDecimal(txtSubtotal.Text);
                decimal discountPercent = 0;

                if (subtotal >= 500)
                {
                    discountPercent = .2m;
                }

                else if (subtotal >= 250 && subtotal < 500)
                {
                    discountPercent = 0.15m;
                }

                else if (subtotal >= 100 && subtotal < 250)
                {
                    discountPercent = .1m;
                }

                else if (subtotal < 0)
                {
                    MessageBox.Show("The number entered needs to be Positive, Reenter Subtotal Value");
                    txtSubtotal.Focus();
                }

                decimal discountAmount = subtotal * discountPercent;
                decimal invoiceTotal = subtotal - discountAmount;

                txtDiscountPercent.Text = discountPercent.ToString("p1");
                txtDiscountAmount.Text = discountPercent.ToString("c");
                txtTotal.Text = invoiceTotal.ToString("c");

                txtSubtotal.Focus();


            }


        }
    }

