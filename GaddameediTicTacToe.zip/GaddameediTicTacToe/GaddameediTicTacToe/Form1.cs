﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaddameediTicTacToe
{
    public partial class Form1 : Form
    {
        private List<playerModel> playersList = new List<playerModel>(2);
        private playerModel currentPlayer;
        private boardModel internalBoardRep = new boardModel();

        private string playerAName;
        private string playerBName;
        private Button[,] newButton = new Button[3, 3];

        int turnCount = 0;
        int gameCount = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Tic Tac Toe... Lets Go");
        }

        private void btnLetsPlay_Click(object sender, EventArgs e)
        {
            playerAName = txtFirstPlayer.Text;
            playerBName = txtSecondPlayer.Text;

            if ((playerAName.Length > 0 && playerBName.Length > 0 && playerAName != playerBName))
            {
                playerModel p;
                p = new playerModel(playerAName, 'X');
                playersList.Add(p);
                p = new playerModel(playerBName, 'O');
                playersList.Add(p);


                currentPlayer = playersList[0];

                displayGameBoard();
            }
            else
            {
                MessageBox.Show("One or both of the names are the same, Reenter your names");
                playerAName = "";
                playerBName = "";
                txtFirstPlayer.Focus();
            }

        }

        private void resetGame()
        {
            prepareForNames();
            internalBoardRep.resetGame();
            turnCount = 0;
        }

        public void prepareForNames()
        {
            txtFirstPlayer.Focus();
            txtSecondPlayer.Visible = false;
            btnOKPlayerTwo.Visible = false;
            lblSecondPlayer.Visible = false;
            lblReadyPlay.Visible = false;
            btnLetsPlay.Visible = false;
            txtFirstPlayer.Text = "";
            txtSecondPlayer.Text = "";
            pnlGame.Visible = false;
        }

        public void displayGameBoard()
        {
            pnlGame.Location = new System.Drawing.Point(32, 232);
            txtCurrentPlayer.Text = playerAName;
            pnlGame.Visible = true;
            createBoard();
        }

        public void createBoard()
        {
            pnlGame.Visible = true;
            Size size = new Size(75, 75);
            Point loc = new Point(0, 0);
            int padding = 25;
            int topMargin = 40;

            for (int row = 0; row <= 2; row++)
            {
                loc.Y = topMargin + row * (size.Height + padding);
                int extraLeftPadding = 80;
                for (int col = 0; col <= 2; col++)
                {
                    newButton[row, col] = new System.Windows.Forms.Button();
                    newButton[row, col].Location = new Point(extraLeftPadding + col * (size.Width + padding), loc.Y);
                    newButton[row, col].Size = size;
                    newButton[row, col].Font = new Font("Arial", 48, FontStyle.Bold);
                    newButton[row, col].Text = "";
                    newButton[row, col].Enabled = true;
                    newButton[row, col].Name = "btn" + (char)row + (char)col;

                    newButton[row, col].Click += new EventHandler(Button_Click);

                    pnlGame.Controls.Add(newButton[row, col]);

                }
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            int rowID = convertCharToInt(((Button)sender).Name[3]) + 48;
            int colID = convertCharToInt(((Button)sender).Name[4]) + 48;
            MessageBox.Show("Cell[" + rowID + "," + colID + "]has been selected");
            int cellID = rowID * 3 + colID;

            internalBoardRep.recordTurn(currentPlayer, cellID);
            string thisToken = (currentPlayer.Icon).ToString();
            ((Button)sender).Text = thisToken;
            if (thisToken == "X") ((Button)sender).ForeColor = Color.Orange;
            ((Button)sender).Enabled = false;

            if (internalBoardRep.hasPlayerWon(currentPlayer.Icon))
            {
                MessageBox.Show("Congrats " + currentPlayer.Name + "You won!");
                currentPlayer.won();
                if (wannaPlayAgain())
                {
                    gameCount++;
                    removeButtonControls();
                    resetGame();
                    return;
                }
                else this.Close();
            }
            else
            {
                turnCount++;
                if (turnCount >= 9)
                {
                    MessageBox.Show("Game over. Looks like a draw");
                    if (wannaPlayAgain())
                    {
                        gameCount++;
                        removeButtonControls();
                        resetGame();
                        return;
                    }
                    else this.Close();
                }
            }
            alternateTurn();
        }

        private void removeButtonControls()
        {
            for (int row = 0; row <= 2; row++)
            {
                for (int col = 0; col <= 2; col++)
                {
                    if (pnlGame.Controls.Contains(newButton[row, col]))
                    {
                        this.newButton[row, col].Click -= new System.EventHandler(this.Button_Click);
                        pnlGame.Controls.Remove(newButton[row, col]);
                        newButton[row, col].Dispose();
                    }//if
                }//col
            }//row
        }//removeButton

        int convertCharToInt(Char c)
        {
            return ((int)(c) - (int)('0'));
        }

        private Boolean wannaPlayAgain()
        {
            DialogResult Info = MessageBox.Show("Do you want to play again?");
            if (Info == DialogResult.Yes) return true;
            else return false;
        }

        private void alternateTurn()
        {

            if (currentPlayer.Icon == playersList[0].Icon)
                currentPlayer = playersList[1];
            else
                currentPlayer = playersList[0];
            txtCurrentPlayer.Text = currentPlayer.Name;
        }//end alternate turn

        public void displayCurrentPlayer()
        {
            txtCurrentPlayer.Text = currentPlayer.Name + " : " + currentPlayer.Icon;
        }

        private void btnOKPlayerOne_Click(object sender, EventArgs e)
        {
            playerAName = txtFirstPlayer.Text;
            if (playerAName == "")
            {
                MessageBox.Show("First player name" + " is a required field. Reenter Name!",
                    "Entry Error!");
                txtFirstPlayer.Focus();
            }
            else
            {
                txtSecondPlayer.Visible = true;
                lblSecondPlayer.Visible = true;
                btnOKPlayerTwo.Visible = true;
                txtSecondPlayer.Focus();
            }

        }

        private void btnOKPlayerTwo_Click(object sender, EventArgs e)
        {
            playerBName = txtSecondPlayer.Text;
            if (playerBName == "")
            {
                MessageBox.Show("Second player name" + " is a required field. Reenter Name!",
                    "Entry Error!");
                txtSecondPlayer.Focus();
            }
            else if (playerAName == playerBName)
            {
                MessageBox.Show("Player names are the same. ReEnter both of the names");
                txtFirstPlayer.Text = "";
            }
            lblWelcome.Visible = true;
            txtFirstPlayer.Visible = true;
            lblReadyPlay.Visible = true;
            lblFirstPlayer.Visible = true;
            lblTurn.Visible = true;
            btnOKPlayerOne.Visible = true;
            txtSecondPlayer.Visible = true;
            lblSecondPlayer.Visible = true;
            btnOKPlayerTwo.Visible = true;
            btnLetsPlay.Visible = true;
            txtCurrentPlayer.Visible = true;
            lblTurn.Visible = true;
            pnlGame.Visible = true;

        }

        private void btnStopGame_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
