﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookstore_Inventory_Project
{
    public partial class frmEmployeePinForm : Form
    {
        
        public frmEmployeePinForm()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToString(txtPin.Text).Length != 4)
                {
                    MessageBox.Show("ReEnter Pin.");
                    MessageBox.Show("Attempts Left: " + (2 - Globals.BookStore.getTryCount()), "Pin does not match AccessID.");
                    Globals.BookStore.incrementTryCount();
                    txtPin.Focus();
                    txtPin.Clear();
                    return;
                }
                if (!Globals.BookStore.EmployeeList.verifyPin(Convert.ToInt32(txtPin.Text)))
                {
                    MessageBox.Show("Attempts Left: " + (2 - Globals.BookStore.getTryCount()), "Pin does not match AccessID.");
                    Globals.BookStore.incrementTryCount();
                    txtPin.Focus();
                    txtPin.Clear();
                    if (!Globals.BookStore.checkTryCount())
                    {
                        MessageBox.Show("You have reached MAX tries.");
                        System.Windows.Forms.Application.Exit();
                    }
                }
                else
                {
                    MessageBox.Show("Pin match.");
                    this.Visible = false;
                    frmTransactionSelect newForm = new frmTransactionSelect();
                    newForm.Show();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Input not valid.");
                txtPin.Focus();
                txtPin.Clear();
                MessageBox.Show("Attempts Left: " + (2 - Globals.BookStore.getTryCount()), "Pin does not match AccessID.");
                Globals.BookStore.incrementTryCount();
            }
            
        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown)
                return;
            Application.Exit();
        }

        
    }
}