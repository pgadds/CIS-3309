﻿namespace Bookstore_Inventory_Project
{
    partial class frmEmployeeAccessIDEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAccessID = new System.Windows.Forms.TextBox();
            this.btnFindMe = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblAccessID = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtAccessID
            // 
            this.txtAccessID.Location = new System.Drawing.Point(332, 436);
            this.txtAccessID.Name = "txtAccessID";
            this.txtAccessID.Size = new System.Drawing.Size(207, 29);
            this.txtAccessID.TabIndex = 0;
            // 
            // btnFindMe
            // 
            this.btnFindMe.Location = new System.Drawing.Point(806, 423);
            this.btnFindMe.Name = "btnFindMe";
            this.btnFindMe.Size = new System.Drawing.Size(157, 57);
            this.btnFindMe.TabIndex = 1;
            this.btnFindMe.Text = "Find Me";
            this.btnFindMe.UseVisualStyleBackColor = true;
            this.btnFindMe.Click += new System.EventHandler(this.btnFindMe_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(462, 48);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(241, 25);
            this.lblWelcome.TabIndex = 2;
            this.lblWelcome.Text = "Welcome to the Bookstore";
            // 
            // lblAccessID
            // 
            this.lblAccessID.AutoSize = true;
            this.lblAccessID.Location = new System.Drawing.Point(291, 298);
            this.lblAccessID.Name = "lblAccessID";
            this.lblAccessID.Size = new System.Drawing.Size(633, 25);
            this.lblAccessID.TabIndex = 3;
            this.lblAccessID.Text = "Enter Your FIVE DIGIT Access ID in the Box Below. Then Click Find Me";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(806, 567);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(157, 52);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click_1);
            // 
            // frmEmployeeAccessIDEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1122, 677);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblAccessID);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.btnFindMe);
            this.Controls.Add(this.txtAccessID);
            this.Name = "frmEmployeeAccessIDEntry";
            this.Text = "frmEmployeeAccessIDEntry";
            this.Load += new System.EventHandler(this.frmEmployeeAccessIDEntry_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAccessID;
        private System.Windows.Forms.Button btnFindMe;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblAccessID;
        private System.Windows.Forms.Button btnExit;
    }
}