﻿namespace Bookstore_Inventory_Project
{
    partial class frmTransactionSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddNewBook = new System.Windows.Forms.Button();
            this.btnUpdateBook = new System.Windows.Forms.Button();
            this.btnDeleteBook = new System.Windows.Forms.Button();
            this.pnlAdd = new System.Windows.Forms.Panel();
            this.btnAddNo = new System.Windows.Forms.Button();
            this.btnAddYes = new System.Windows.Forms.Button();
            this.txtAddTransactionDate = new System.Windows.Forms.TextBox();
            this.txtAddOnHand = new System.Windows.Forms.TextBox();
            this.txtAddPrice = new System.Windows.Forms.TextBox();
            this.txtAddAuthor = new System.Windows.Forms.TextBox();
            this.txtAddTitle = new System.Windows.Forms.TextBox();
            this.txtAddISBN = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblAddBook = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblSelectTransaction = new System.Windows.Forms.Label();
            this.txtFirstISBN = new System.Windows.Forms.TextBox();
            this.txtSecondISBN = new System.Windows.Forms.TextBox();
            this.btnOKIsbn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.txtAddDate = new System.Windows.Forms.TextBox();
            this.lblAddDate = new System.Windows.Forms.Label();
            this.pnlModify = new System.Windows.Forms.Panel();
            this.lblModifyBook = new System.Windows.Forms.Label();
            this.txtModifyDate = new System.Windows.Forms.TextBox();
            this.txtModifyOnHand = new System.Windows.Forms.TextBox();
            this.txtModifyPrice = new System.Windows.Forms.TextBox();
            this.txtModifyAuthor = new System.Windows.Forms.TextBox();
            this.txtModifyTitle = new System.Windows.Forms.TextBox();
            this.txtModifyISBN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.pnlDelete = new System.Windows.Forms.Panel();
            this.lblDeleteBook = new System.Windows.Forms.Label();
            this.txtDeleteISBN = new System.Windows.Forms.TextBox();
            this.txtDeleteTitle = new System.Windows.Forms.TextBox();
            this.txtDeleteAuthor = new System.Windows.Forms.TextBox();
            this.txtDeletePrice = new System.Windows.Forms.TextBox();
            this.txtDeleteOnHand = new System.Windows.Forms.TextBox();
            this.txtDeleteTransactionDate = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.btnDeleteYes = new System.Windows.Forms.Button();
            this.btnDeleteNo = new System.Windows.Forms.Button();
            this.btnModifyYes = new System.Windows.Forms.Button();
            this.btnModifyNo = new System.Windows.Forms.Button();
            this.pnlAdd.SuspendLayout();
            this.pnlModify.SuspendLayout();
            this.pnlDelete.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(405, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Transaction Select";
            // 
            // btnAddNewBook
            // 
            this.btnAddNewBook.Enabled = false;
            this.btnAddNewBook.Location = new System.Drawing.Point(364, 213);
            this.btnAddNewBook.Name = "btnAddNewBook";
            this.btnAddNewBook.Size = new System.Drawing.Size(352, 36);
            this.btnAddNewBook.TabIndex = 1;
            this.btnAddNewBook.Text = "ADD NEW BOOK TO INVENTORY";
            this.btnAddNewBook.UseVisualStyleBackColor = true;
            this.btnAddNewBook.Visible = false;
            this.btnAddNewBook.Click += new System.EventHandler(this.btnAddNewBook_Click_1);
            // 
            // btnUpdateBook
            // 
            this.btnUpdateBook.Enabled = false;
            this.btnUpdateBook.Location = new System.Drawing.Point(364, 279);
            this.btnUpdateBook.Name = "btnUpdateBook";
            this.btnUpdateBook.Size = new System.Drawing.Size(352, 35);
            this.btnUpdateBook.TabIndex = 2;
            this.btnUpdateBook.Text = "UPDATE A BOOK IN INVENTORY";
            this.btnUpdateBook.UseVisualStyleBackColor = true;
            this.btnUpdateBook.Visible = false;
            this.btnUpdateBook.Click += new System.EventHandler(this.btnUpdateBook_Click_1);
            // 
            // btnDeleteBook
            // 
            this.btnDeleteBook.Enabled = false;
            this.btnDeleteBook.Location = new System.Drawing.Point(351, 341);
            this.btnDeleteBook.Name = "btnDeleteBook";
            this.btnDeleteBook.Size = new System.Drawing.Size(382, 35);
            this.btnDeleteBook.TabIndex = 3;
            this.btnDeleteBook.Text = "DELETE A BOOK FROM INVENTORY";
            this.btnDeleteBook.UseVisualStyleBackColor = true;
            this.btnDeleteBook.Visible = false;
            this.btnDeleteBook.Click += new System.EventHandler(this.btnDeleteBook_Click_1);
            // 
            // pnlAdd
            // 
            this.pnlAdd.Controls.Add(this.btnAddNo);
            this.pnlAdd.Controls.Add(this.btnAddYes);
            this.pnlAdd.Controls.Add(this.txtAddTransactionDate);
            this.pnlAdd.Controls.Add(this.txtAddOnHand);
            this.pnlAdd.Controls.Add(this.txtAddPrice);
            this.pnlAdd.Controls.Add(this.txtAddAuthor);
            this.pnlAdd.Controls.Add(this.txtAddTitle);
            this.pnlAdd.Controls.Add(this.txtAddISBN);
            this.pnlAdd.Controls.Add(this.label8);
            this.pnlAdd.Controls.Add(this.label7);
            this.pnlAdd.Controls.Add(this.label6);
            this.pnlAdd.Controls.Add(this.label5);
            this.pnlAdd.Controls.Add(this.label4);
            this.pnlAdd.Controls.Add(this.label3);
            this.pnlAdd.Controls.Add(this.lblAddBook);
            this.pnlAdd.Enabled = false;
            this.pnlAdd.Location = new System.Drawing.Point(177, 410);
            this.pnlAdd.Name = "pnlAdd";
            this.pnlAdd.Size = new System.Drawing.Size(785, 322);
            this.pnlAdd.TabIndex = 4;
            this.pnlAdd.Visible = false;
            // 
            // btnAddNo
            // 
            this.btnAddNo.Location = new System.Drawing.Point(659, 18);
            this.btnAddNo.Name = "btnAddNo";
            this.btnAddNo.Size = new System.Drawing.Size(92, 37);
            this.btnAddNo.TabIndex = 14;
            this.btnAddNo.Text = "NO";
            this.btnAddNo.UseVisualStyleBackColor = true;
            this.btnAddNo.Click += new System.EventHandler(this.btnAddNo_Click_1);
            // 
            // btnAddYes
            // 
            this.btnAddYes.Location = new System.Drawing.Point(553, 16);
            this.btnAddYes.Name = "btnAddYes";
            this.btnAddYes.Size = new System.Drawing.Size(78, 39);
            this.btnAddYes.TabIndex = 13;
            this.btnAddYes.Text = "YES";
            this.btnAddYes.UseVisualStyleBackColor = true;
            this.btnAddYes.Click += new System.EventHandler(this.btnAddYes_Click_1);
            // 
            // txtAddTransactionDate
            // 
            this.txtAddTransactionDate.Location = new System.Drawing.Point(591, 240);
            this.txtAddTransactionDate.Name = "txtAddTransactionDate";
            this.txtAddTransactionDate.Size = new System.Drawing.Size(160, 29);
            this.txtAddTransactionDate.TabIndex = 12;
            // 
            // txtAddOnHand
            // 
            this.txtAddOnHand.Location = new System.Drawing.Point(591, 157);
            this.txtAddOnHand.Name = "txtAddOnHand";
            this.txtAddOnHand.Size = new System.Drawing.Size(160, 29);
            this.txtAddOnHand.TabIndex = 11;
            // 
            // txtAddPrice
            // 
            this.txtAddPrice.Location = new System.Drawing.Point(591, 90);
            this.txtAddPrice.Name = "txtAddPrice";
            this.txtAddPrice.Size = new System.Drawing.Size(160, 29);
            this.txtAddPrice.TabIndex = 10;
            // 
            // txtAddAuthor
            // 
            this.txtAddAuthor.Location = new System.Drawing.Point(175, 240);
            this.txtAddAuthor.Name = "txtAddAuthor";
            this.txtAddAuthor.Size = new System.Drawing.Size(160, 29);
            this.txtAddAuthor.TabIndex = 9;
            // 
            // txtAddTitle
            // 
            this.txtAddTitle.Location = new System.Drawing.Point(175, 157);
            this.txtAddTitle.Name = "txtAddTitle";
            this.txtAddTitle.Size = new System.Drawing.Size(160, 29);
            this.txtAddTitle.TabIndex = 8;
            // 
            // txtAddISBN
            // 
            this.txtAddISBN.Location = new System.Drawing.Point(175, 86);
            this.txtAddISBN.Name = "txtAddISBN";
            this.txtAddISBN.Size = new System.Drawing.Size(160, 29);
            this.txtAddISBN.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(411, 240);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(161, 25);
            this.label8.TabIndex = 6;
            this.label8.Text = "Transaction Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(411, 161);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 25);
            this.label7.TabIndex = 5;
            this.label7.Text = "On Hand";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(411, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 25);
            this.label5.TabIndex = 3;
            this.label5.Text = "Author";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 25);
            this.label4.TabIndex = 2;
            this.label4.Text = "Title";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "ISBN";
            // 
            // lblAddBook
            // 
            this.lblAddBook.AutoSize = true;
            this.lblAddBook.Location = new System.Drawing.Point(21, 23);
            this.lblAddBook.Name = "lblAddBook";
            this.lblAddBook.Size = new System.Drawing.Size(283, 25);
            this.lblAddBook.TabIndex = 0;
            this.lblAddBook.Text = "Enter Data for New Book Below";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(69, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(389, 25);
            this.label9.TabIndex = 5;
            this.label9.Text = "Enter the ISBN for Book (In form nnn-nnn)...";
            // 
            // lblSelectTransaction
            // 
            this.lblSelectTransaction.AutoSize = true;
            this.lblSelectTransaction.Enabled = false;
            this.lblSelectTransaction.Location = new System.Drawing.Point(69, 158);
            this.lblSelectTransaction.Name = "lblSelectTransaction";
            this.lblSelectTransaction.Size = new System.Drawing.Size(206, 25);
            this.lblSelectTransaction.TabIndex = 6;
            this.lblSelectTransaction.Text = "Select a Transaction...";
            this.lblSelectTransaction.Visible = false;
            // 
            // txtFirstISBN
            // 
            this.txtFirstISBN.Location = new System.Drawing.Point(592, 97);
            this.txtFirstISBN.Name = "txtFirstISBN";
            this.txtFirstISBN.Size = new System.Drawing.Size(100, 29);
            this.txtFirstISBN.TabIndex = 7;
            // 
            // txtSecondISBN
            // 
            this.txtSecondISBN.Location = new System.Drawing.Point(751, 98);
            this.txtSecondISBN.Name = "txtSecondISBN";
            this.txtSecondISBN.Size = new System.Drawing.Size(100, 29);
            this.txtSecondISBN.TabIndex = 8;
            // 
            // btnOKIsbn
            // 
            this.btnOKIsbn.Location = new System.Drawing.Point(904, 88);
            this.btnOKIsbn.Name = "btnOKIsbn";
            this.btnOKIsbn.Size = new System.Drawing.Size(108, 51);
            this.btnOKIsbn.TabIndex = 9;
            this.btnOKIsbn.Text = "OK";
            this.btnOKIsbn.UseVisualStyleBackColor = true;
            this.btnOKIsbn.Click += new System.EventHandler(this.btnOKIsbn_Click_1);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(714, 100);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(19, 25);
            this.label11.TabIndex = 10;
            this.label11.Text = "-";
            // 
            // btnDone
            // 
            this.btnDone.Location = new System.Drawing.Point(904, 310);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(112, 47);
            this.btnDone.TabIndex = 11;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click_1);
            // 
            // txtAddDate
            // 
            this.txtAddDate.Enabled = false;
            this.txtAddDate.Location = new System.Drawing.Point(633, 155);
            this.txtAddDate.Name = "txtAddDate";
            this.txtAddDate.Size = new System.Drawing.Size(115, 29);
            this.txtAddDate.TabIndex = 12;
            this.txtAddDate.Visible = false;
            // 
            // lblAddDate
            // 
            this.lblAddDate.AutoSize = true;
            this.lblAddDate.Enabled = false;
            this.lblAddDate.Location = new System.Drawing.Point(425, 158);
            this.lblAddDate.Name = "lblAddDate";
            this.lblAddDate.Size = new System.Drawing.Size(104, 25);
            this.lblAddDate.TabIndex = 13;
            this.lblAddDate.Text = "Enter Date";
            this.lblAddDate.Visible = false;
            // 
            // pnlModify
            // 
            this.pnlModify.Controls.Add(this.btnModifyNo);
            this.pnlModify.Controls.Add(this.btnModifyYes);
            this.pnlModify.Controls.Add(this.label16);
            this.pnlModify.Controls.Add(this.label15);
            this.pnlModify.Controls.Add(this.label14);
            this.pnlModify.Controls.Add(this.label13);
            this.pnlModify.Controls.Add(this.label12);
            this.pnlModify.Controls.Add(this.label2);
            this.pnlModify.Controls.Add(this.lblModifyBook);
            this.pnlModify.Controls.Add(this.txtModifyDate);
            this.pnlModify.Controls.Add(this.txtModifyOnHand);
            this.pnlModify.Controls.Add(this.txtModifyPrice);
            this.pnlModify.Controls.Add(this.txtModifyAuthor);
            this.pnlModify.Controls.Add(this.txtModifyTitle);
            this.pnlModify.Controls.Add(this.txtModifyISBN);
            this.pnlModify.Enabled = false;
            this.pnlModify.Location = new System.Drawing.Point(1036, 410);
            this.pnlModify.Name = "pnlModify";
            this.pnlModify.Size = new System.Drawing.Size(806, 316);
            this.pnlModify.TabIndex = 15;
            this.pnlModify.Visible = false;
            // 
            // lblModifyBook
            // 
            this.lblModifyBook.AutoSize = true;
            this.lblModifyBook.Location = new System.Drawing.Point(36, 25);
            this.lblModifyBook.Name = "lblModifyBook";
            this.lblModifyBook.Size = new System.Drawing.Size(126, 25);
            this.lblModifyBook.TabIndex = 15;
            this.lblModifyBook.Text = "Modify Book:";
            // 
            // txtModifyDate
            // 
            this.txtModifyDate.Location = new System.Drawing.Point(550, 219);
            this.txtModifyDate.Name = "txtModifyDate";
            this.txtModifyDate.Size = new System.Drawing.Size(141, 29);
            this.txtModifyDate.TabIndex = 5;
            // 
            // txtModifyOnHand
            // 
            this.txtModifyOnHand.Location = new System.Drawing.Point(550, 154);
            this.txtModifyOnHand.Name = "txtModifyOnHand";
            this.txtModifyOnHand.Size = new System.Drawing.Size(141, 29);
            this.txtModifyOnHand.TabIndex = 4;
            // 
            // txtModifyPrice
            // 
            this.txtModifyPrice.Location = new System.Drawing.Point(550, 82);
            this.txtModifyPrice.Name = "txtModifyPrice";
            this.txtModifyPrice.Size = new System.Drawing.Size(141, 29);
            this.txtModifyPrice.TabIndex = 3;
            // 
            // txtModifyAuthor
            // 
            this.txtModifyAuthor.Location = new System.Drawing.Point(192, 220);
            this.txtModifyAuthor.Name = "txtModifyAuthor";
            this.txtModifyAuthor.Size = new System.Drawing.Size(139, 29);
            this.txtModifyAuthor.TabIndex = 2;
            // 
            // txtModifyTitle
            // 
            this.txtModifyTitle.Location = new System.Drawing.Point(192, 154);
            this.txtModifyTitle.Name = "txtModifyTitle";
            this.txtModifyTitle.Size = new System.Drawing.Size(139, 29);
            this.txtModifyTitle.TabIndex = 1;
            // 
            // txtModifyISBN
            // 
            this.txtModifyISBN.Location = new System.Drawing.Point(192, 83);
            this.txtModifyISBN.Name = "txtModifyISBN";
            this.txtModifyISBN.Size = new System.Drawing.Size(139, 29);
            this.txtModifyISBN.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(359, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 25);
            this.label2.TabIndex = 16;
            this.label2.Text = "Modify Price";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(359, 158);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(154, 25);
            this.label12.TabIndex = 17;
            this.label12.Text = "Modify On Hand";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(370, 223);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 25);
            this.label13.TabIndex = 18;
            this.label13.Text = "Modify Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(41, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 25);
            this.label14.TabIndex = 19;
            this.label14.Text = "Modify ISBN";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(41, 158);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(112, 25);
            this.label15.TabIndex = 20;
            this.label15.Text = "Modify Title";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(41, 222);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(133, 25);
            this.label16.TabIndex = 21;
            this.label16.Text = "Modify Author";
            // 
            // pnlDelete
            // 
            this.pnlDelete.Controls.Add(this.btnDeleteNo);
            this.pnlDelete.Controls.Add(this.btnDeleteYes);
            this.pnlDelete.Controls.Add(this.label22);
            this.pnlDelete.Controls.Add(this.label21);
            this.pnlDelete.Controls.Add(this.label20);
            this.pnlDelete.Controls.Add(this.label19);
            this.pnlDelete.Controls.Add(this.label18);
            this.pnlDelete.Controls.Add(this.label17);
            this.pnlDelete.Controls.Add(this.txtDeleteTransactionDate);
            this.pnlDelete.Controls.Add(this.txtDeleteOnHand);
            this.pnlDelete.Controls.Add(this.txtDeletePrice);
            this.pnlDelete.Controls.Add(this.txtDeleteAuthor);
            this.pnlDelete.Controls.Add(this.txtDeleteTitle);
            this.pnlDelete.Controls.Add(this.txtDeleteISBN);
            this.pnlDelete.Controls.Add(this.lblDeleteBook);
            this.pnlDelete.Enabled = false;
            this.pnlDelete.Location = new System.Drawing.Point(1036, 60);
            this.pnlDelete.Name = "pnlDelete";
            this.pnlDelete.Size = new System.Drawing.Size(806, 316);
            this.pnlDelete.TabIndex = 16;
            this.pnlDelete.Visible = false;
            // 
            // lblDeleteBook
            // 
            this.lblDeleteBook.AutoSize = true;
            this.lblDeleteBook.Location = new System.Drawing.Point(28, 19);
            this.lblDeleteBook.Name = "lblDeleteBook";
            this.lblDeleteBook.Size = new System.Drawing.Size(118, 25);
            this.lblDeleteBook.TabIndex = 0;
            this.lblDeleteBook.Text = "Delete Book";
            // 
            // txtDeleteISBN
            // 
            this.txtDeleteISBN.Location = new System.Drawing.Point(227, 90);
            this.txtDeleteISBN.Name = "txtDeleteISBN";
            this.txtDeleteISBN.Size = new System.Drawing.Size(140, 29);
            this.txtDeleteISBN.TabIndex = 1;
            // 
            // txtDeleteTitle
            // 
            this.txtDeleteTitle.Location = new System.Drawing.Point(227, 156);
            this.txtDeleteTitle.Name = "txtDeleteTitle";
            this.txtDeleteTitle.Size = new System.Drawing.Size(140, 29);
            this.txtDeleteTitle.TabIndex = 2;
            // 
            // txtDeleteAuthor
            // 
            this.txtDeleteAuthor.Location = new System.Drawing.Point(227, 227);
            this.txtDeleteAuthor.Name = "txtDeleteAuthor";
            this.txtDeleteAuthor.Size = new System.Drawing.Size(140, 29);
            this.txtDeleteAuthor.TabIndex = 3;
            // 
            // txtDeletePrice
            // 
            this.txtDeletePrice.Location = new System.Drawing.Point(636, 99);
            this.txtDeletePrice.Name = "txtDeletePrice";
            this.txtDeletePrice.Size = new System.Drawing.Size(140, 29);
            this.txtDeletePrice.TabIndex = 4;
            // 
            // txtDeleteOnHand
            // 
            this.txtDeleteOnHand.Location = new System.Drawing.Point(636, 160);
            this.txtDeleteOnHand.Name = "txtDeleteOnHand";
            this.txtDeleteOnHand.Size = new System.Drawing.Size(140, 29);
            this.txtDeleteOnHand.TabIndex = 5;
            // 
            // txtDeleteTransactionDate
            // 
            this.txtDeleteTransactionDate.Location = new System.Drawing.Point(636, 224);
            this.txtDeleteTransactionDate.Name = "txtDeleteTransactionDate";
            this.txtDeleteTransactionDate.Size = new System.Drawing.Size(140, 29);
            this.txtDeleteTransactionDate.TabIndex = 6;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(37, 90);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(119, 25);
            this.label17.TabIndex = 7;
            this.label17.Text = "Delete ISBN";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(37, 155);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(110, 25);
            this.label18.TabIndex = 8;
            this.label18.Text = "Delete Title";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(37, 231);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(131, 25);
            this.label19.TabIndex = 9;
            this.label19.Text = "Delete Author";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(397, 97);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(117, 25);
            this.label20.TabIndex = 10;
            this.label20.Text = "Delete Price";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(409, 160);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(152, 25);
            this.label21.TabIndex = 11;
            this.label21.Text = "Delete On Hand";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(409, 223);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(222, 25);
            this.label22.TabIndex = 12;
            this.label22.Text = "Delete Transaction Date";
            // 
            // btnDeleteYes
            // 
            this.btnDeleteYes.Location = new System.Drawing.Point(581, 19);
            this.btnDeleteYes.Name = "btnDeleteYes";
            this.btnDeleteYes.Size = new System.Drawing.Size(86, 43);
            this.btnDeleteYes.TabIndex = 13;
            this.btnDeleteYes.Text = "YES";
            this.btnDeleteYes.UseVisualStyleBackColor = true;
            this.btnDeleteYes.Click += new System.EventHandler(this.btnDeleteYes_Click_1);
            // 
            // btnDeleteNo
            // 
            this.btnDeleteNo.Location = new System.Drawing.Point(695, 19);
            this.btnDeleteNo.Name = "btnDeleteNo";
            this.btnDeleteNo.Size = new System.Drawing.Size(81, 43);
            this.btnDeleteNo.TabIndex = 14;
            this.btnDeleteNo.Text = "NO";
            this.btnDeleteNo.UseVisualStyleBackColor = true;
            this.btnDeleteNo.Click += new System.EventHandler(this.btnDeleteNo_Click_1);
            // 
            // btnModifyYes
            // 
            this.btnModifyYes.Location = new System.Drawing.Point(550, 18);
            this.btnModifyYes.Name = "btnModifyYes";
            this.btnModifyYes.Size = new System.Drawing.Size(81, 37);
            this.btnModifyYes.TabIndex = 22;
            this.btnModifyYes.Text = "YES";
            this.btnModifyYes.UseVisualStyleBackColor = true;
            this.btnModifyYes.Click += new System.EventHandler(this.btnModifyYes_Click_1);
            // 
            // btnModifyNo
            // 
            this.btnModifyNo.Location = new System.Drawing.Point(683, 18);
            this.btnModifyNo.Name = "btnModifyNo";
            this.btnModifyNo.Size = new System.Drawing.Size(83, 40);
            this.btnModifyNo.TabIndex = 23;
            this.btnModifyNo.Text = "NO";
            this.btnModifyNo.UseVisualStyleBackColor = true;
            this.btnModifyNo.Click += new System.EventHandler(this.btnModifyNo_Click_1);
            // 
            // frmTransactionSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1863, 776);
            this.Controls.Add(this.pnlDelete);
            this.Controls.Add(this.pnlModify);
            this.Controls.Add(this.lblAddDate);
            this.Controls.Add(this.txtAddDate);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnOKIsbn);
            this.Controls.Add(this.txtSecondISBN);
            this.Controls.Add(this.txtFirstISBN);
            this.Controls.Add(this.lblSelectTransaction);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pnlAdd);
            this.Controls.Add(this.btnDeleteBook);
            this.Controls.Add(this.btnUpdateBook);
            this.Controls.Add(this.btnAddNewBook);
            this.Controls.Add(this.label1);
            this.Name = "frmTransactionSelect";
            this.Text = "frmTransactionSelect";
            this.pnlAdd.ResumeLayout(false);
            this.pnlAdd.PerformLayout();
            this.pnlModify.ResumeLayout(false);
            this.pnlModify.PerformLayout();
            this.pnlDelete.ResumeLayout(false);
            this.pnlDelete.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddNewBook;
        private System.Windows.Forms.Button btnUpdateBook;
        private System.Windows.Forms.Button btnDeleteBook;
        private System.Windows.Forms.Panel pnlAdd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAddTransactionDate;
        private System.Windows.Forms.TextBox txtAddOnHand;
        private System.Windows.Forms.TextBox txtAddPrice;
        private System.Windows.Forms.TextBox txtAddAuthor;
        private System.Windows.Forms.TextBox txtAddTitle;
        private System.Windows.Forms.TextBox txtAddISBN;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblSelectTransaction;
        private System.Windows.Forms.Button btnAddNo;
        private System.Windows.Forms.Button btnAddYes;
        private System.Windows.Forms.TextBox txtFirstISBN;
        private System.Windows.Forms.TextBox txtSecondISBN;
        private System.Windows.Forms.Button btnOKIsbn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.TextBox txtAddDate;
        private System.Windows.Forms.Label lblAddDate;
        private System.Windows.Forms.Label lblAddBook;
        private System.Windows.Forms.Panel pnlModify;
        private System.Windows.Forms.Label lblModifyBook;
        private System.Windows.Forms.TextBox txtModifyDate;
        private System.Windows.Forms.TextBox txtModifyOnHand;
        private System.Windows.Forms.TextBox txtModifyPrice;
        private System.Windows.Forms.TextBox txtModifyAuthor;
        private System.Windows.Forms.TextBox txtModifyTitle;
        private System.Windows.Forms.TextBox txtModifyISBN;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlDelete;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtDeleteTransactionDate;
        private System.Windows.Forms.TextBox txtDeleteOnHand;
        private System.Windows.Forms.TextBox txtDeletePrice;
        private System.Windows.Forms.TextBox txtDeleteAuthor;
        private System.Windows.Forms.TextBox txtDeleteTitle;
        private System.Windows.Forms.TextBox txtDeleteISBN;
        private System.Windows.Forms.Label lblDeleteBook;
        private System.Windows.Forms.Button btnDeleteNo;
        private System.Windows.Forms.Button btnDeleteYes;
        private System.Windows.Forms.Button btnModifyNo;
        private System.Windows.Forms.Button btnModifyYes;
    }
}