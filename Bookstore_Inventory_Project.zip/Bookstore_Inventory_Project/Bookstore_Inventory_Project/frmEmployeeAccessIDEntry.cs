﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookstore_Inventory_Project
{
    public partial class frmEmployeeAccessIDEntry : Form
    {
        public frmEmployeeAccessIDEntry()
        {
            InitializeComponent();
        }

        private void frmEmployeeAccessIDEntry_Load_1(object sender, EventArgs e)
        {
            Globals.BookStore.EmployeeList.initializeEntireList();  
        }

        private void btnFindMe_Click(object sender, EventArgs e)
        {
            try
            {
                EmployeeClass emp;
                bool found = false;
                if (Convert.ToString(txtAccessID.Text).Length != 5)
                {
                    MessageBox.Show("Input does not meet requirements.");
                    MessageBox.Show("Attempts Left: " + (2 - Globals.BookStore.getTryCount()), "Cannot find AccessID.");
                    Globals.BookStore.incrementTryCount();
                    txtAccessID.Focus();
                    txtAccessID.Clear();
                    return;
                }
                emp = Globals.BookStore.findEmployee(Convert.ToInt32(txtAccessID.Text), out found);
                if (found == true)
                {
                    MessageBox.Show("Employee Found.");
                }
                else
                {
                    MessageBox.Show("Attempts Left: " + (2-Globals.BookStore.getTryCount()), "Cannot find AccessID.");
                    Globals.BookStore.incrementTryCount();
                    txtAccessID.Focus();
                    txtAccessID.Clear();
                    if (!Globals.BookStore.checkTryCount())
                    {
                        MessageBox.Show("Max tries.");
                        System.Windows.Forms.Application.Exit();
                    }
                    return;
                }

                this.Visible = false;
                frmEmployeePinForm newForm = new frmEmployeePinForm();
                newForm.Show();
            }
            catch (FormatException)
            {
                MessageBox.Show("Input does not meet requirements.");
                MessageBox.Show("Attempts Left: " + (2 - Globals.BookStore.getTryCount()), "Cannot find AccessID.");
                Globals.BookStore.incrementTryCount();
                txtAccessID.Focus();
                txtAccessID.Clear();
            }

        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown)
                return;
            Application.Exit();

        }

        
    }
}
