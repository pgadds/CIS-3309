﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PranavG_Lab5._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            //calls the clear form funtion which allows a clear board to be formed
            InitializeComponent();
            clearForm();
        }



        private void clearForm()
        {
            //diables everything but the yearly intrest rate
            lblMonthlyInvestment.Enabled = false;
            lblYearlyInterestRate.Enabled = false;
            lblNumberofYears.Enabled = false;
            label4.Enabled = false;
            txtMonthlyInvestment.Enabled = false;
            txtInterestRate.Enabled = false;
            txtFutureValue.Enabled = false;
            txtNumberofYears.Enabled = false;
            btnCalculate.Enabled = false;

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            //calculate function click formula from textbook
            decimal monthlyInvestment = Convert.ToDecimal(txtMonthlyInvestment.Text);
            decimal yearlyInterestRate = Convert.ToDecimal(txtInterestRate.Text);
            int years = Convert.ToInt32(txtNumberofYears.Text);

            int months = years * 12;
            decimal monthlyInterestRate = yearlyInterestRate / 12 / 100;

            decimal futureValue = 0m;
           
            for (int i = 0; i < months; i++)
            {
                futureValue = (futureValue + monthlyInvestment)
                    * (1 + monthlyInterestRate);
            }

            txtFutureValue.Text = futureValue.ToString("c");
            
            txtMonthlyInvestment.Focus();
            
            MessageBox.Show("If you want another calculation press Enter Data Button.",
                "Re-Run!"); //asks if you want to enter a new set of data for next calulation
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNumberofYears_TextChanged(object sender, EventArgs e)
        {
            btnCalculate.Enabled = true;
        }

        private void btnEnterData_Click_1(object sender, EventArgs e)
        {
            txtMonthlyInvestment.Enabled = true;
            txtMonthlyInvestment.Text = "";
            lblMonthlyInvestment.Enabled = true;
            txtInterestRate.Enabled = true;
            txtInterestRate.Text = "";
            txtFutureValue.Enabled = true;
            txtFutureValue.Text = "";
            lblFutureValue.Enabled = true;
            txtNumberofYears.Enabled = true;
            txtNumberofYears.Text = "";
            lblNumberofYears.Enabled = true;
            
            lblYearlyInterestRate.Enabled = true;
           
            btnCalculate.Enabled = false;
        }
    }
}
//3 Possible advantages: 
//1. Allows the user to enter multiple different calculations,
//2. The form looks cleaner 
//3. Calculations flow more logically through allowing only the yearly interest rate to be entered at first

