﻿namespace PranavG_Lab5._2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtMonthlyInvestment = new System.Windows.Forms.TextBox();
            this.txtYearlyInvestment = new System.Windows.Forms.TextBox();
            this.txtNumberofYears = new System.Windows.Forms.TextBox();
            this.lblMonthlyInvestment = new System.Windows.Forms.Label();
            this.lblYearlyInterestRate = new System.Windows.Forms.Label();
            this.lblNumberofYears = new System.Windows.Forms.Label();
            this.lblFutureValue = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFutureValue = new System.Windows.Forms.TextBox();
            this.txtInterestRate = new System.Windows.Forms.TextBox();
            this.btnEnterData = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(129, 453);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(130, 50);
            this.btnCalculate.TabIndex = 0;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(711, 596);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(98, 50);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtMonthlyInvestment
            // 
            this.txtMonthlyInvestment.Location = new System.Drawing.Point(410, 129);
            this.txtMonthlyInvestment.Name = "txtMonthlyInvestment";
            this.txtMonthlyInvestment.Size = new System.Drawing.Size(149, 29);
            this.txtMonthlyInvestment.TabIndex = 2;
            // 
            // txtYearlyInvestment
            // 
            this.txtYearlyInvestment.Location = new System.Drawing.Point(410, 226);
            this.txtYearlyInvestment.Name = "txtYearlyInvestment";
            this.txtYearlyInvestment.Size = new System.Drawing.Size(149, 29);
            this.txtYearlyInvestment.TabIndex = 3;
            // 
            // txtNumberofYears
            // 
            this.txtNumberofYears.Location = new System.Drawing.Point(410, 316);
            this.txtNumberofYears.Name = "txtNumberofYears";
            this.txtNumberofYears.Size = new System.Drawing.Size(149, 29);
            this.txtNumberofYears.TabIndex = 4;
            this.txtNumberofYears.TextChanged += new System.EventHandler(this.txtNumberofYears_TextChanged);
            // 
            // lblMonthlyInvestment
            // 
            this.lblMonthlyInvestment.AutoSize = true;
            this.lblMonthlyInvestment.Location = new System.Drawing.Point(124, 133);
            this.lblMonthlyInvestment.Name = "lblMonthlyInvestment";
            this.lblMonthlyInvestment.Size = new System.Drawing.Size(181, 25);
            this.lblMonthlyInvestment.TabIndex = 5;
            this.lblMonthlyInvestment.Text = "Monthly Investment";
            // 
            // lblYearlyInterestRate
            // 
            this.lblYearlyInterestRate.AutoSize = true;
            this.lblYearlyInterestRate.Location = new System.Drawing.Point(124, 230);
            this.lblYearlyInterestRate.Name = "lblYearlyInterestRate";
            this.lblYearlyInterestRate.Size = new System.Drawing.Size(181, 25);
            this.lblYearlyInterestRate.TabIndex = 6;
            this.lblYearlyInterestRate.Text = "Yearly Interest Rate";
            // 
            // lblNumberofYears
            // 
            this.lblNumberofYears.AutoSize = true;
            this.lblNumberofYears.Location = new System.Drawing.Point(124, 320);
            this.lblNumberofYears.Name = "lblNumberofYears";
            this.lblNumberofYears.Size = new System.Drawing.Size(158, 25);
            this.lblNumberofYears.TabIndex = 7;
            this.lblNumberofYears.Text = "Number of Years";
            // 
            // lblFutureValue
            // 
            this.lblFutureValue.AutoSize = true;
            this.lblFutureValue.Location = new System.Drawing.Point(124, 572);
            this.lblFutureValue.Name = "lblFutureValue";
            this.lblFutureValue.Size = new System.Drawing.Size(124, 25);
            this.lblFutureValue.TabIndex = 9;
            this.lblFutureValue.Text = "Future Value";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(342, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(217, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Future Value Calculator";
            // 
            // txtFutureValue
            // 
            this.txtFutureValue.Location = new System.Drawing.Point(396, 569);
            this.txtFutureValue.Name = "txtFutureValue";
            this.txtFutureValue.Size = new System.Drawing.Size(163, 29);
            this.txtFutureValue.TabIndex = 10;
            // 
            // txtInterestRate
            // 
            this.txtInterestRate.Location = new System.Drawing.Point(687, 120);
            this.txtInterestRate.Name = "txtInterestRate";
            this.txtInterestRate.Size = new System.Drawing.Size(122, 29);
            this.txtInterestRate.TabIndex = 11;
            // 
            // btnEnterData
            // 
            this.btnEnterData.Location = new System.Drawing.Point(21, 36);
            this.btnEnterData.Name = "btnEnterData";
            this.btnEnterData.Size = new System.Drawing.Size(83, 82);
            this.btnEnterData.TabIndex = 13;
            this.btnEnterData.Text = "Enter Data";
            this.btnEnterData.UseVisualStyleBackColor = true;
            this.btnEnterData.Click += new System.EventHandler(this.btnEnterData_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(682, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 25);
            this.label1.TabIndex = 14;
            this.label1.Text = "Interest Rate:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 699);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnEnterData);
            this.Controls.Add(this.txtInterestRate);
            this.Controls.Add(this.txtFutureValue);
            this.Controls.Add(this.lblFutureValue);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblNumberofYears);
            this.Controls.Add(this.lblYearlyInterestRate);
            this.Controls.Add(this.lblMonthlyInvestment);
            this.Controls.Add(this.txtNumberofYears);
            this.Controls.Add(this.txtYearlyInvestment);
            this.Controls.Add(this.txtMonthlyInvestment);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtMonthlyInvestment;
        private System.Windows.Forms.TextBox txtYearlyInvestment;
        private System.Windows.Forms.TextBox txtNumberofYears;
        private System.Windows.Forms.Label lblMonthlyInvestment;
        private System.Windows.Forms.Label lblYearlyInterestRate;
        private System.Windows.Forms.Label lblNumberofYears;
        private System.Windows.Forms.Label lblFutureValue;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFutureValue;
        private System.Windows.Forms.TextBox txtInterestRate;
        private System.Windows.Forms.Button btnEnterData;
        private System.Windows.Forms.Label label1;
    }
}

