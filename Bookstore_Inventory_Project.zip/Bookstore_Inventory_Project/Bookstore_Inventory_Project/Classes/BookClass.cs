﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookstore_Inventory_Project
{
    class BookClass
    {
     private string hiddenISBN = "XXX-XXX";
        private string hiddenTitle = "";
        private string hiddenAuthor = "";
        private decimal hiddenPrice = 0.0m;
        private int hiddenNumberOnHand = 0;
        private DateTime hiddenLastDateOfTransaction = default(DateTime);
        private string[] hiddenBookAttributes = new string[6];

        //Default constructor
        public BookClass()
        {
        }

        
        public BookClass(string isbn, string title, string author, decimal price, int numberOnHand, DateTime lastTransactionDate)
        {
            this.hiddenISBN = isbn;
            this.hiddenTitle = title;
            this.hiddenAuthor = author;
            this.hiddenPrice = price;
            this.hiddenNumberOnHand = numberOnHand;
            this.hiddenLastDateOfTransaction = lastTransactionDate;
        }

        //Book Object is created
        public Boolean createBookObject(string s)  // IN: string from the Employee Text File
        {
            BookClass book = this;
            string[] bookString = s.Split('*');
            int i;
            for (i = 0; i < bookString.Length - 1; i++) //for loop
            {
                string newString = bookString[i].Trim();
                bookString[i] = newString;
            }

            int employeeStringSize = bookString.GetLength(0);

            // Convert AccessID to int
            if (bookString[0].Length != Globals.BookStore.getHiddenISBNTotalLength())
            {
                MessageBox.Show(bookString[0]
                    + ": ISBN string is not exactly 7 characters. Book File Corrupt. Execution Terminated.",
                      "ISBN in Book File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            //ISBN to String
            try
            {
                hiddenISBN = Convert.ToString(bookString[0]);
            }
            catch
            {
                MessageBox.Show(bookString[0]
                    + " ISBN string is not a valid ISBN string. Book File Corrupt. Execution Terminated.",
                      "ISBN in Book File Invalid",
                       MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }

            // Looks for string name
            hiddenTitle = bookString[1];
            if (hiddenTitle == " " || hiddenTitle == "")
            {
                MessageBox.Show(hiddenTitle
                    + ": Title string is empty or Blank. Book File Corrupt. Execution Terminated.",
                      "Title in Book File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }

            try //Author to string
            {
                hiddenAuthor = Convert.ToString(bookString[2]);
            }
            catch
            {
                MessageBox.Show(bookString[2]
                    + ": Author string is empty or Blank. Book File Corrupt.  Execution Terminated.",
                      "Author in Book File Invalid", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            
            try//price to decimal
            {
                hiddenPrice = Convert.ToDecimal(bookString[3].Replace(".",
                    ".").Replace("$", ""));
            }
            catch
            {
                MessageBox.Show(bookString[3]
                    + ": Price string is not a valid decimal. Book File Corrupt. Execution Terminated.",
                      "Price in Book File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            
            try // Number on hand to int
            {
                hiddenNumberOnHand = Convert.ToInt32(bookString[4]);
            }
            catch
            {
                MessageBox.Show(bookString[4]
                    + ": Number on hand string is not a valid integer. Book File Corrupt. Execution Terminated.",
                      "Number on hand in Book File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            
            try //Last date of access to date
            {
                hiddenLastDateOfTransaction = DateTime.Parse(bookString[5]);
            }
            catch
            {
                MessageBox.Show(bookString[5]
                    + ": Date of Last transaction string is not a valid date. Book File Corrupt.  Execution Terminated.",
                      "Date of last transaction in Book File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }

            
            return (true);
        }//End of book object method

        
        public bool bookMatch(string ISBN)
        {
            if (!this.hiddenISBN.Equals(ISBN))
            {
                return false;
            }
            else
                return true;
        }

        //String with book object attributes
        public string displayBookRecord()
        {
            string message = "ISBN: " + this.hiddenISBN + "\n"
                  + "Title: " + this.hiddenTitle + "\n"
                  + "Author: " + this.hiddenAuthor + "\n"
                  + "Price: " + hiddenPrice + "\n"
                  + "On Hand: " + hiddenNumberOnHand + "\n"
                  + "Last Inventory Transaction: " + hiddenLastDateOfTransaction;
            return message;
        }

        //creates a string to write to a file
        public string createBookWrite()
        {
            string writeString = this.hiddenISBN + " * " + this.hiddenTitle + " * " + this.hiddenAuthor + " * $" + this.hiddenPrice + " * " + this.hiddenNumberOnHand + " * " + this.hiddenLastDateOfTransaction;
            return writeString;
        }
        
        
        public void createBookAttributes() //string array is created
        {
            hiddenBookAttributes[0] = this.hiddenISBN;
            hiddenBookAttributes[1] = this.hiddenTitle;
            hiddenBookAttributes[2] = this.hiddenAuthor;
            hiddenBookAttributes[3] = Convert.ToString(this.hiddenPrice);
            hiddenBookAttributes[4] = Convert.ToString(this.hiddenNumberOnHand);
            hiddenBookAttributes[5] = Convert.ToString(this.hiddenLastDateOfTransaction);
        }
        
        
        public string[] returnBookAttributeArray() //book array string is returned
        {
            BookClass book = this;
            book.createBookAttributes();
            return hiddenBookAttributes;
        }
    }
}
